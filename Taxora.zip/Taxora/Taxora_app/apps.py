from django.apps import AppConfig


class TaxoraAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Taxora_app'
